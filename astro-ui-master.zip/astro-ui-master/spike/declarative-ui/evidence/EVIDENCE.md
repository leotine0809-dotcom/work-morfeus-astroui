# Phase 31 t14 — Done-check evidence

Run 2026-09-03, from `spike/declarative-ui/` on this machine, Claude CLI already authenticated
(`claude.cmd` on PATH via npm global). All commands below were run for real, not simulated.

## C1 — live `claude -p` call, fails loudly when unavailable/unauth

**Positive path.** `npm run generate` (unmodified `src/generate.ts`, t12) made a real
`claude -p` call and wrote a validated simplified-A2UI tree to
`examples/conversation.a2ui.json` (gitignored):

```
> declarative-ui@0.0.0 generate
> tsx src/generate.ts

generate: wrote 7 node(s) to C:\AI ARMY\astro-ui\spike\declarative-ui\examples\conversation.a2ui.json
```

The written tree is a 7-node A2UI-shaped document: `root` = `ConversationItem` (Mara Solari,
channel "Astrochat", carrying `childrenIds` to 5 `MessageBubble` nodes with alternating
`direction: "in"/"out"` + `time`, and one `Composer` node) — content invented live by the model,
matching `a2uiTreeSchema` (t6). **Not a committed fixture** — the file is gitignored and was
freshly deleted + regenerated for this run.

**Negative path 1 — missing binary.** Ran `npm run generate` with the npm-global bin directory
(where `claude.cmd` lives) stripped from `PATH`:

```
generate: claude -p exited 1: 'claude.cmd' is not recognized as an internal or external command,
operable program or batch file.
```

Fails loudly, non-zero exit, no tree written (verified `examples/conversation.a2ui.json` was
untouched by the failed run).

**Negative path 2 — unauthenticated CLI.** Ran `npm run generate` with `CLAUDE_CONFIG_DIR`
pointed at a nonexistent/empty directory (so the CLI has no session to use):

```
generate: claude -p exited 1
```

Also fails loudly (non-zero exit surfaced by `runClaudePrint`), no tree written. Both negative
paths confirm the generate step never completes green without a real, authenticated CLI call —
**C1 holds.**

## C2 — declared tree renders into the real shadcn components, declared props drive output — PARTIAL, gap found

Built (`npm run build`) with the live tree above, served (`vite preview`), and inspected with a
headless Chromium (Playwright) both visually (`evidence/conversation-dark.png`) and via raw DOM
(`document.querySelector("#root").innerHTML`):

```html
<div class="dark min-h-svh bg-background text-foreground">
  <div class="mx-auto flex max-w-md flex-col gap-4 px-4 py-8">
    <div data-slot="conversation-item" data-selected="true" class="... bg-accent">
      <div class="shrink-0">
        <span data-slot="avatar" ...><span data-slot="avatar-fallback" ...>Ma</span></span>
      </div>
      <div class="min-w-0 flex-1">
        <div class="..."><span class="...">Mara Solari</span></div>
        <div class="...">Astrochat</div>
        <div class="...">Perfect — locking it in now ✨</div>
      </div>
    </div>
  </div>
</div>
```

**What works:** the root node (`ConversationItem`) renders as the real shadcn-based component,
themed, with the LLM-declared props (`name`, `channel`, `preview`, `avatarSrc`/fallback,
`selected`) driving the output verbatim — re-running `generate` with different model output (Mara
Voss → Mara Solari across two live calls) produced correspondingly different on-screen text
without any code change, confirming the props-drive-output half of C2.

**What does not work:** the tree's other 6 nodes (5 `MessageBubble` + 1 `Composer`, referenced via
the root's `childrenIds`) are validated and pass allow-list + Zod (they're present and correct in
the adapter's `Spec.elements`), but **never reach the DOM**. Root cause, traced to source:

- `@json-render/react`'s `Renderer` only mounts a node's children if the registry component
  function accepts and renders json-render's `children` render-prop
  (`node_modules/@json-render/react/dist/index.mjs`: `Component({ element, slots, emit, on,
  bindings, loading, children })` — the component itself must place `{children}` in its JSX; this
  matches the package's own README: `Card: ({ props, children }) => (<div>...{children}</div>)`).
- `src/registry.ts` (t8) wraps every one of the four components as
  `({ props }) => React.createElement(Component, props)` — it discards json-render's `children`
  prop entirely, for all four entries.
- None of `Avatar`/`MessageBubble`/`ConversationItem`/`Composer` (t2–t5) render `props.children`
  either — they are all leaf, single-purpose components by design (t4's own comment: "avatar +
  name + channel + preview line", not a container).

Net effect: **no A2UI tree, of any shape, can currently compose more than one visible primitive**
through this pipeline — only the `root` node ever mounts, everything under `childrenIds` is
silently dropped (allow-listed and Zod-valid, but orphaned). This was not previously exercised
end-to-end: t9/t10's reject tests (t13) only assert on *rejection* (single offending node, thrown
before render), and t11's wiring only confirmed `tsc`/`vite build` green, not a rendered
screenshot — this done-check is the first task to actually look at the output, which is exactly
what caught it.

**This is a real integration gap, not a t14 scope item to silently patch** (t14's declared files
are `evidence/EVIDENCE.md` + `evidence/conversation-dark.png` only). Flagging as a blocker for a
follow-up task: either (a) `registry.ts`'s wrappers forward `children` and the 4 components render
it (turns `ConversationItem` into a conversation container, which conflicts with t4's "it's a list
row" design), or (b) the A2UI tree/registry gains a 5th, generic container primitive whose only
job is to lay out `children` (a `Conversation`/`Thread` wrapper), or (c) `app.tsx`/`generate.ts`
stop relying on nesting and instead mount N independent single-node A2UI trees side by side. This
is an architecture decision belonging to t4/t8/t11/t12's owners, not a 2-file done-check task.

## C3 — unknown component rejected, never rendered

`npm run test` — both reject tests pass:

```
 RUN  v4.1.11 C:/AI ARMY/astro-ui/spike/declarative-ui
 Test Files  1 passed (1)
      Tests  2 passed (2)
```

`renderConversation — reject unknown component types (C3)`: feeding
`examples/fixtures/unknown-component.a2ui.json` (a valid `ConversationItem` root whose
`childrenIds` includes a node declaring `type: "EvilWidget"`) through the real
`renderConversation` throws `UnknownComponentTypeError` naming both the offending type
(`"EvilWidget"`) and node id (`"intruder"`), before anything renders. **Passes.**

## C4 — invalid props rejected by Zod before render

`renderConversation — reject invalid component props (C4)`: feeding
`examples/fixtures/invalid-prop.a2ui.json` (a valid `MessageBubble` whose `text` is a number, not
a string) through the same path throws `InvalidComponentPropsError` naming the component
(`"MessageBubble"`), node (`"root"`), and prop (`"text"`), with no `[object Object]`/`undefined`
in the message. **Passes.**

## C5 — dark theme, accent distinction

The rendered root node confirms the dark token set is applied and resolved (not raw/light
shadcn): `bg-background`/`text-foreground` on the page wrapper resolve to the `.dark` oklch
values in `src/globals.css`, `bg-accent` fills the selected `ConversationItem` row, legible
foreground text. The in/out bubble accent distinction (`--bubble-in` vs `--bubble-out` +
`--bubble-out-foreground`) is correctly wired in `message-bubble.tsx`'s classes and the token
file, but **could not be visually confirmed in this run's screenshot** because — per the C2
finding above — no `MessageBubble` node reaches the DOM through a nested tree. C5's
token-application half holds; the bubble-accent half is blocked on the same C2 gap.

## C6 — zero SOMA dependencies

- `grep -rn "@soma" src package.json` → no matches.
- `npm run build` with `SOMA_SUBSTRATE` unset (`env -u SOMA_SUBSTRATE npm run build`) → succeeds,
  identical output to the run with it set:
  ```
  ✓ built in 1.36s
  ```
- No `@soma/*` module resolution anywhere in the dependency graph (`package.json` dependencies
  are all third-party: json-render, radix-ui, zod, tailwind, etc.). **Holds.**

## Screenshot

`evidence/conversation-dark.png` — 480x800 headless Chromium capture of the live-generated
conversation (`claude -p` output above) rendered through the real pipeline, dark theme. Shows the
one primitive that currently mounts (`ConversationItem`, themed, avatar fallback, live LLM
content) — see the C2 finding for what's missing and why.

## Summary

| Criterion | Result |
|---|---|
| C1 — live CLI call, fails loudly unavailable/unauth | ✅ both directions verified live |
| C2 — 4 primitives compose one conversation, props drive output | ⚠️ partial — props-drive-output holds; multi-node composition is broken (see gap above) |
| C3 — unknown component rejected | ✅ `npm run test`, 1/1 |
| C4 — invalid prop rejected by Zod | ✅ `npm run test`, 1/1 |
| C5 — dark theme + accent distinction | ⚠️ partial — tokens resolve correctly; bubble accent unverifiable on screen (blocked by C2) |
| C6 — zero SOMA deps | ✅ verified with `SOMA_SUBSTRATE` unset |

The spike answers its core question with a caveat: the loop **LLM declares → allow-listed →
Zod-validated → real shadcn component renders** is proven end-to-end for a single node (C1, C3,
C4, C6 all hold cleanly, and C2/C5 hold for one primitive at a time). What is **not** yet proven is
multi-primitive **composition** — the piece needed to show "one astrochat conversation" — because
the registry (t8) never forwards json-render's `children` to any of the four leaf components
(t2–t5). This is the concrete, named blocker for whoever picks up the next task on this phase.
